// Makes each function easier to read on console.
var start = "start", // Makes each function easier to read on console.
    end = "end"; // phrase to type into readability() function to console.log end of program statement

function readability(input) {
    console.log(
        "----------------------------------------------------------------------------------------------------"
    );
    console.log(
        "****************************************************************************************************"
    );
    console.log(
        "----------------------------------------------------------------------------------------------------"
    );
    if (input == "start") {
        console.log("Start of Program");
    } else if (input == "end") {
        console.log("End of Program");
    } else if (input !== "start" && input !== "end") {
        // simple check for people entering other variables `end` or nothing at all into the function
        console.log("Next Function");
    }
    console.log(
        "----------------------------------------------------------------------------------------------------"
    );
    return 0;
}

var users = [
    { name: "Michael", age: 37 },
    { name: "John", age: 30 },
    { name: "David", age: 27 },
];

// How would you print/log John's age?
readability(start);

console.log(users[1].age);

readability();

// How would you print/log the name of the first object?
console.log(users[0]);

readability();

// How would you print/log the name and age of each user using a for loop?  Your output should look something like this
for (var i = 0; i < users.length; i++) {
    console.log(users[i]);
}

readability(end);
