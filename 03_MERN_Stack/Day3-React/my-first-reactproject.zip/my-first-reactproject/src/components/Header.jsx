import React from 'react';



const Header = () => {
    return(
        <div>
            <h1>Hello Dojo!</h1>
            <h2>Things I need to do:</h2>
            {/* <ul>
                <li>Learn React</li>
                <li>Climb Mt. Everest</li>
                <li>Run a marathon</li>
                <li>Feed the dogs</li>
            </ul> */}
            <p>*  Learn React</p>
            <p>*  Climb Mt. Everest</p>
            <p>*  Run a marathon</p>
            <p>*  Feed the dogs</p>
        </div>
    );
}





export default Header;