// 1-create a Ninja class  
// 2-add attributes: name, health, speed(default value- 3), strength(default value-3)
// 3-add methods: sayName(this logs Ninjas name to console), showStats (shows Ninja name, strength, speed, and health), drinkSake (should add +10 health to Ninja)



class Ninja {
    constructor(name, health = 0, speed = 3, strength = 3) {
        this.name = name;
        this.health = health;
        this.speed = speed;
        this.strength = strength;
    }

    sayName() {
        console.log(`Ninjas Name: ${this.name}`);
    }

    showStats() {
        console.log(`Ninjas Name: ${this.name}`);
        console.log(`Ninjas Strength: ${this.strength}`);
        console.log(`Ninjas Speed: ${this.speed}`);
        console.log(`Ninjas Health: ${this.health}`);
    }

    drinkSake() {
        console.log(`${this.name}'s health value is ${this.health} but drank Sake.`);
        this.health += 10;
        console.log('********************');
        console.log(`${this.name} added ${this.health} to his health.`);
        this.showStats();
        console.log('********************');
    }
}

class Sensei extends Ninja {
    constructor(name, health = 200, speed = 10, strength = 10, wisdom = 10) {
        super(name);        
        this.health = health;
        this.speed = speed;
        this.strength = strength;
        this.wisdom = wisdom;
    }
    
    speakWisdom(){                       //NEED TO FIX THE THIS.HEALTH FOR SENSEI...THE FLOW ISN'T TAKING IN THE DEFAULT VALUE OF 200. AFTER SAKE, ITS INCREASING BY 210 NOT 10

        console.log("Victory is sweetest when you've known defeat")
    }
}


const ninja1 = new Ninja("Fujibayashi Nagato");
const superSensei = new Sensei("Obi Wan Kenobi")
// ninja1.sayName();
ninja1.showStats();
ninja1.drinkSake();
superSensei.drinkSake();
superSensei.speakWisdom();












