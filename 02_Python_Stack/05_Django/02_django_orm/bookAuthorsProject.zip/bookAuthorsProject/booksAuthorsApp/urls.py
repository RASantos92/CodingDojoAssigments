from django.urls import path
from . import views


urlpatterns = [
    #
    #           Books
    #
    path('', views.index),
    path("createBook", views.createBook),
    path("books/<int:titleID>", views.showTitle),
    path("addAuthor/<int:bookinfo>", views.addAuthor),
    path("delete/<int:titleID>", views.deleteBook),
    path("edit/<int:titleID>", views.editBook),
    path("update/<int:titleID>", views.updateBook),
    #
    #           Authors
    #
    path("makeAuthorpage", views.makeAuthorpage),
    path("createAuthor", views.createAuthor),
    path("author/<int:authorID>", views.showAuthor),
    path("addBookToAuthor/<int:authorID>", views.addBookToAuthor),
    path("deleteAuthor/<int:authorID>", views.deleteAuthor),
    path("editAuthor/<int:authorID>", views.editAuthorpage),
    path("updateAuthor/<int:authorID>", views.updateAuthor),
]











