from django.apps import AppConfig


class TimedisplayAppConfig(AppConfig):
    name = 'TimeDisplay_app'
