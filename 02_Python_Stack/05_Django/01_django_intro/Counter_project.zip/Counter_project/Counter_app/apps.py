from django.apps import AppConfig


class CounterAppConfig(AppConfig):
    name = 'Counter_app'
