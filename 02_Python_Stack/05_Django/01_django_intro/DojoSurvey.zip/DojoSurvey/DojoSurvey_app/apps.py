from django.apps import AppConfig


class DojosurveyAppConfig(AppConfig):
    name = 'DojoSurvey_app'
