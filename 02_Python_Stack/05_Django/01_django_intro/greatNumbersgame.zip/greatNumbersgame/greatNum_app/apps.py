from django.apps import AppConfig


class GreatnumAppConfig(AppConfig):
    name = 'greatNum_app'
